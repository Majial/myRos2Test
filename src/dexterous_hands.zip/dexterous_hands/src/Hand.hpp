#ifndef HAND_H_
#define HAND_H_

#include "simple_serial_port.h"

#include <iostream>
#include <chrono>
#include <memory>
#include <string>

#include <rclcpp/rclcpp.hpp>
#include <message_interfaces/msg/hand_ctl.hpp>
#include <message_interfaces/msg/hand_state.hpp>
#include <std_msgs/msg/string.hpp>

using namespace std::chrono_literals;
using std::placeholders::_1;

class Hand : public rclcpp::Node, public SimpleSerialPort
{
private:
    /* data */
    // 串口
    std::string port_;
    int rate_;
    // 电机站号
    uint8_t motor_id_;
    // 控制手臂打开/关闭
    uint8_t motot_control[18] = {0x3E, 0xA4, 0x01, 0x0C, 0x00,
                                 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    // 查手臂当前状态 读取电机状态
    uint8_t motor_state[5] = {0x3E, 0x9C, 0x01, 0x00, 0x00};
    // 手臂开机 点击运行命令
    uint8_t motor_start[6] = {0x3E, 0x88, 0x01, 0x00, 0x00, 0x00};
    // 手臂关机 电机关闭命令
    uint8_t motor_stop[6] = {0x3E, 0x80, 0x01, 0x00, 0x00, 0x00};
    static const int serial_port_buffer_length_current = 18;
    uint8_t serialPortReceiveBuffer[serial_port_buffer_length_current];

    // rclcpp
    rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::Publisher<message_interfaces::msg::HandState>::SharedPtr publisher_;
    rclcpp::Subscription<message_interfaces::msg::HandCtl>::SharedPtr subscription_;

    void timer_callback();
    void hand_ctl_callback(const message_interfaces::msg::HandCtl &msg);

    // 校验和  返回一个字节
    unsigned char Check(const unsigned char *buf, int len);
    // bool set_hand_id(uint8_t m_id);
    // bool set_rate(int m_rate);
    // bool set_port(std::string m_port);
    bool set_speed(uint32_t m_speed);
    bool set_position(uint64_t m_position);

public:
    Hand() = delete;
    Hand(std::string m_node_name, std::string m_port, uint32_t m_rate, uint8_t m_id);
    ~Hand();

    bool hand_control(int64_t m_position = 0, uint32_t m_speed = 5000);
    bool read_state();
};

#endif /*HAND_H_*/
