#include "Hand.hpp"


int main(int argc , char**argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<Hand>("hand_ctl","/dev/ttyUSB1",115200,1));
    rclcpp::shutdown();
    return 0;
}
