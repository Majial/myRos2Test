#include "Hand.hpp"

void Hand::timer_callback()
{
    if (isOpen())
    {
        if (read_state())
        {
            auto hand_state_msg = message_interfaces::msg::HandState();
            hand_state_msg.speed = (serialPortReceiveBuffer[9] << 8) | serialPortReceiveBuffer[8];
            hand_state_msg.position = (serialPortReceiveBuffer[11] << 8) | serialPortReceiveBuffer[10];
            hand_state_msg.is_grabbed = false;
            // RCLCPP_INFO(this->get_logger(), "Publishing : '%d' '%d", hand_state_msg.speed, hand_state_msg.position);
            publisher_->publish(hand_state_msg);
            /* code */
        }
    }
}

void Hand::hand_ctl_callback(const message_interfaces::msg::HandCtl &msg)
{
    // RCLCPP_INFO(this->get_logger(), "I heard : '%d'  '%ld'", msg.speed, msg.position);
    auto hand_ctl_msg = message_interfaces::msg::HandCtl();
    hand_ctl_msg.speed = msg.speed;
    hand_ctl_msg.position = msg.position;
    if (isOpen())
    {
        /* code */
        hand_control(hand_ctl_msg.position, hand_ctl_msg.speed);
    }
}

unsigned char Hand::Check(const unsigned char *buf, int len)
{
    int iSum = 0;
    for (int i = 0; i < len; i++)
    {
        iSum += buf[i];
    }
    iSum &= 0xff; // 也可以&0xff
    return (unsigned char)iSum;
}

// bool Hand::set_hand_id(uint8_t m_id)
// {
//     motor_id_ = m_id;
//     motor_start[2] = m_id;
//     motor_stop[2] = m_id;
//     motor_state[2] = m_id;
//     motot_control[2] = m_id;
//     return true;
// }

// bool Hand::set_rate(int m_rate)
// {
//     rate_ = m_rate;
//     return true;
// }

// bool Hand::set_port(std::string m_port)
// {
//     port_ = m_port;
//     return true;
// }

bool Hand::set_speed(uint32_t m_speed)
{
    m_speed *= 100;
    motot_control[13] = *(uint8_t *)(&m_speed);
    motot_control[14] = *((uint8_t *)(&m_speed) + 1);
    motot_control[15] = *((uint8_t *)(&m_speed) + 2);
    motot_control[16] = *((uint8_t *)(&m_speed) + 3);
    return true;
    return false;
}

bool Hand::set_position(uint64_t m_position)
{
    m_position *= 100;
    motot_control[5] = *(uint8_t *)(&m_position);
    motot_control[6] = *((uint8_t *)(&m_position) + 1);
    motot_control[7] = *((uint8_t *)(&m_position) + 2);
    motot_control[8] = *((uint8_t *)(&m_position) + 3);
    motot_control[9] = *((uint8_t *)(&m_position) + 4);
    motot_control[10] = *((uint8_t *)(&m_position) + 5);
    motot_control[11] = *((uint8_t *)(&m_position) + 6);
    motot_control[12] = *((uint8_t *)(&m_position) + 7);
    return true;
}

Hand::Hand(std::string m_node_name, std::string m_port, uint32_t m_rate, uint8_t m_id) : Node(m_node_name), port_(m_port), rate_(m_rate), motor_id_(m_id)
{
    motor_start[2] = motor_id_;
    motor_stop[2] = motor_id_;
    motor_state[2] = motor_id_;
    motot_control[2] = motor_id_;
    motor_state[4] = Check(motor_state, 4);
    if (openPort(port_.c_str(), rate_))
    {
        std::cout << "OPEN serial port: " << port_ << "  success" << std::endl;
    }
    else
    {
        std::cerr << "OPEN serial port: " << port_ << " failed" << std::endl;
        exit(-1);
    }
    publisher_ = this->create_publisher<message_interfaces::msg::HandState>("/hand_state", 1);
    timer_ = this->create_wall_timer(
        0.2ms, std::bind(&Hand::timer_callback, this));
    subscription_ = this->create_subscription<message_interfaces::msg::HandCtl>(
        "/hand_ctl", 1, std::bind(&Hand::hand_ctl_callback, this, _1));
}

Hand::~Hand()
{
}

bool Hand::hand_control(int64_t m_position, uint32_t m_speed)
{
    set_position(m_position);
    set_speed(m_speed);
    motot_control[4] = Check(motot_control, 4);
    motot_control[17] = Check(motot_control + 5, 12);
    if (sendBytes(motot_control, 18))
    {
        // usleep(1000*20);
        // usleep(250);
        int read_length = recieveBytes(serialPortReceiveBuffer, serial_port_buffer_length_current);
        if (read_length > 0 && serialPortReceiveBuffer[1] == 0xA4)
        {
                   printf("rebk: ");
                   for (int i = 0; i < read_length && i < serial_port_buffer_length_current; i++)
                   {
                       printf("<%02X> ", serialPortReceiveBuffer[i]);
                   }
                   printf("\n");
            return true;
        }
        else
        {
            std::cerr << "read control data failed ! " << std::endl;
            return false;
        }
    }
    std::cerr << "send control data failed ! " << std::endl;
    return false;
}

bool Hand::read_state()
{
    if (sendBytes(motor_state, 5))
    {
        // usleep(1000*20);
        // usleep(250);
        memset(serialPortReceiveBuffer, 0x00, sizeof(serialPortReceiveBuffer));
        int read_length = recieveBytes(serialPortReceiveBuffer, serial_port_buffer_length_current);
        if (read_length > 0 && serialPortReceiveBuffer[1] == 0x9C )
        {
                   printf("rebk: ");
                   for (int i = 0; i < read_length && i < serial_port_buffer_length_current; i++)
                   {
                       printf("<%02X> ", serialPortReceiveBuffer[i]);
                   }
                   printf("\n");
            return true;
        }
        else
        {
            std::cerr << "read state data failed ! " << std::endl;
            return false;
        }
    }
    else
    {
        std::cerr << "send read state data failed ! " << std::endl;
        return false;
    }
}
