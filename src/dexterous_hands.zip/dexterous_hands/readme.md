### run program
```
ros2 run dexterous_hands hand_main 
```
### control topic pub 
```
ros2 topic pub /hand_ctl message_interfaces/msg/HandCtl '{position: 100, speed: 200}'
```