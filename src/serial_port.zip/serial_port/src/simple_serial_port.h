#ifndef SIMPLE_SERIALPORT_H_
#define SIMPLE_SERIALPORT_H_

#include <stdint.h>


class SimpleSerialPort {
public:
	static const unsigned int MAX_SEND_BYTES_PER_TIME = 1024;

private:
	int file_discripter;
	bool is_open;


public:
	bool openPort(const char *device_name, int baud_rate_int);
	bool closePort();
	bool isOpen();
	bool sendBytes(const uint8_t *data, uint32_t length);
	int recieveBytes(uint8_t *buffer, uint32_t max_length);




public:
	SimpleSerialPort();
	virtual ~SimpleSerialPort();


};

#endif /* SIMPLE_SERIALPORT_H_ */
