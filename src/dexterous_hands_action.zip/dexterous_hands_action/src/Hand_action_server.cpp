#include "simple_serial_port.h"

#include <functional>
#include <memory>
#include <thread>

#include "rclcpp/rclcpp.hpp"
#include "rclcpp_action/rclcpp_action.hpp"
#include "rclcpp_components/register_node_macro.hpp"
#include "action_interfaces/action/hand.hpp"
// #include <logging.hpp>

namespace hand_action_namespace
{
    class HandActionServer : public rclcpp::Node, public SimpleSerialPort
    {
    public:
        using HandAction = action_interfaces::action::Hand;
        using GoalHandleHand = rclcpp_action::ServerGoalHandle<HandAction>;
        // 显式构造函数,示例化新的动作服务器
        explicit HandActionServer(const rclcpp::NodeOptions &options = rclcpp::NodeOptions())
            : Node("hand_action_server", options)//, motor_id_(0x01), port_("/dev/ttyUSB0"), rate_(115200)
        {
            using namespace std::placeholders;
            this->action_server_ = rclcpp_action::create_server<HandAction>(
                this,
                "hand",
                std::bind(&HandActionServer::handle_goal, this, _1, _2),
                std::bind(&HandActionServer::handle_cancel, this, _1),
                std::bind(&HandActionServer::handle_accepted, this, _1));
            motor_start[2] = motor_id_;
            motor_stop[2] = motor_id_;
            motor_state[2] = motor_id_;
            motot_control[2] = motor_id_;
            motor_state[4] = Check(motor_state, 4);
            if (openPort(port_.c_str(), rate_))
            {
                std::cout << "OPEN serial port: " << port_ << "  success" << std::endl;
                read_state();
            }
            else
            {
                std::cerr << "OPEN serial port: " << port_ << " failed" << std::endl;
                exit(-1);
            }
        }
        bool hand_control(int64_t m_position = 0, uint32_t m_speed = 5000)
        {
            set_position(m_position);
            set_speed(m_speed);
            motot_control[4] = Check(motot_control, 4);
            motot_control[17] = Check(motot_control + 5, 12);
            if (sendBytes(motot_control, 18))
            {
                int read_length = recieveBytes(serialPortReceiveBuffer, serial_port_buffer_length_current);
                if (read_length > 0 && serialPortReceiveBuffer[1] == 0xA4)
                {
                    printf("rebk: ");
                    for (int i = 0; i < read_length && i < serial_port_buffer_length_current; i++)
                    {
                        printf("<%02X> ", serialPortReceiveBuffer[i]);
                    }
                    printf("\n");
                    return true;
                }
                else
                {
                    std::cerr << "read control data failed ! " << std::endl;
                    return false;
                }
            }
            std::cerr << "send control data failed ! " << std::endl;
            return false;
        }
        bool read_state()
        {
            if (sendBytes(motor_state, 5))
            {
                memset(serialPortReceiveBuffer, 0x00, sizeof(serialPortReceiveBuffer));
                int read_length = recieveBytes(serialPortReceiveBuffer, serial_port_buffer_length_current);
                if (read_length > 0 && serialPortReceiveBuffer[1] == 0x9C)
                {
                    printf("rebk: ");
                    for (int i = 0; i < read_length && i < serial_port_buffer_length_current; i++)
                    {
                        printf("<%02X> ", serialPortReceiveBuffer[i]);
                    }
                    printf("\n");
                    return true;
                }
                else
                {
                    std::cerr << "read state data failed ! " << std::endl;
                    return false;
                }
            }
            else
            {
                std::cerr << "send read state data failed ! " << std::endl;
                return false;
            }
        }

    private:
        // 动作服务器句柄
        rclcpp_action::Server<HandAction>::SharedPtr action_server_;

        /* data */
        // 串口
        std::string port_ = "/dev/ttyUSB0";
        int rate_ = 115200;
        // 电机站号
        uint8_t motor_id_ = 0x01;
        // 控制手臂打开/关闭
        uint8_t motot_control[18] = {0x3E, 0xA4, 0x01, 0x0C, 0x00,
                                     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
        // 查手臂当前状态 读取电机状态
        uint8_t motor_state[5] = {0x3E, 0x9C, 0x01, 0x00, 0x00};
        // 手臂开机 点击运行命令
        uint8_t motor_start[6] = {0x3E, 0x88, 0x01, 0x00, 0x00, 0x00};
        // 手臂关机 电机关闭命令
        uint8_t motor_stop[6] = {0x3E, 0x80, 0x01, 0x00, 0x00, 0x00};
        // 接收缓冲区
        static const int serial_port_buffer_length_current = 18;
        uint8_t serialPortReceiveBuffer[serial_port_buffer_length_current];

        // 校验和  返回一个字节
        unsigned char Check(const unsigned char *buf, int len)
        {
            int iSum = 0;
            for (int i = 0; i < len; i++)
            {
                iSum += buf[i];
            }
            iSum &= 0xff; // 也可以&0xff
            return (unsigned char)iSum;
        }
        bool set_speed(uint32_t m_speed)
        {
            m_speed *= 100;
            motot_control[13] = *(uint8_t *)(&m_speed);
            motot_control[14] = *((uint8_t *)(&m_speed) + 1);
            motot_control[15] = *((uint8_t *)(&m_speed) + 2);
            motot_control[16] = *((uint8_t *)(&m_speed) + 3);
            return true;
            return false;
        }
        bool set_position(uint64_t m_position)
        {
            m_position *= 100;
            motot_control[5] = *(uint8_t *)(&m_position);
            motot_control[6] = *((uint8_t *)(&m_position) + 1);
            motot_control[7] = *((uint8_t *)(&m_position) + 2);
            motot_control[8] = *((uint8_t *)(&m_position) + 3);
            motot_control[9] = *((uint8_t *)(&m_position) + 4);
            motot_control[10] = *((uint8_t *)(&m_position) + 5);
            motot_control[11] = *((uint8_t *)(&m_position) + 6);
            motot_control[12] = *((uint8_t *)(&m_position) + 7);
            return true;
        }

        // 接收新目标
        rclcpp_action::GoalResponse handle_goal(
            const rclcpp_action::GoalUUID &uuid,
            std::shared_ptr<const HandAction::Goal> goal)
        {
            // 打印日志
            RCLCPP_INFO(this->get_logger(), "Received goal request with position %ld, speed %d",
                        goal->position, goal->speed);

            (void)uuid;
            return rclcpp_action::GoalResponse::ACCEPT_AND_EXECUTE;
        }
        // 取消目标
        rclcpp_action::CancelResponse handle_cancel(
            const std::shared_ptr<GoalHandleHand> goal_handle)
        {
            RCLCPP_INFO(this->get_logger(), "Received request to cancle goal");
            (void)goal_handle;
            return rclcpp_action::CancelResponse::ACCEPT;
        }
        // 确认收到目标后,执行
        void handle_accepted(const std::shared_ptr<GoalHandleHand> goal_handle)
        {
            using namespace std::placeholders;
            // this needs to return quickly to avoid blocking the executor, so spin up a new thread
            // 这需要快速返回以避免阻塞执行器，因此请启动一个新线程
            std::thread{std::bind(&HandActionServer::execute, this, _1), goal_handle}.detach();
        }
        // 执行目标函数
        void execute(const std::shared_ptr<GoalHandleHand> goal_handle)
        {
            RCLCPP_INFO(this->get_logger(), "Executing goal");
            // 执行频率
            rclcpp::Rate loop_rate(0.5);
            // 获取目标值
            const auto goal = goal_handle->get_goal();
            // 初始化Feedback,feedback内容为实时反馈的状态
            auto feedback = std::make_shared<HandAction::Feedback>();
            auto &position = feedback->position;
            auto &speed = feedback->speed;
            // result 表示Result,动作执行的结果
            auto result = std::make_shared<HandAction::Result>();

            // 这里是执行动作的过程
            if (isOpen())
            {
                hand_control(goal->position, goal->speed);
                // 由于灵巧手没有位置反馈和抓取反馈,这里只能使用循环次数来进行测试
                for (int i = 0; i < 10; i++)
                {
                    /* code */
                    if (goal_handle->is_canceling())
                    {
                        /* code */
                        result->is_grabbed = false;
                        goal_handle->canceled(result);
                        RCLCPP_INFO(this->get_logger(), "Goal canceled");
                        return;
                    }
                    if (read_state())
                    {
                        // 更新当前状态
                        speed = (serialPortReceiveBuffer[9] << 8) | serialPortReceiveBuffer[8];
                        position = (serialPortReceiveBuffer[11] << 8) | serialPortReceiveBuffer[10];
                        // 发布状态
                        goal_handle->publish_feedback(feedback);
                        RCLCPP_INFO(this->get_logger(), "publish feedback");
                    }
                    loop_rate.sleep();
                }
            }

            // 检查动作是否执行成功
            if (rclcpp::ok())
            {
                result->is_grabbed = true;
                goal_handle->succeed(result);
                RCLCPP_INFO(this->get_logger(), "Goal successed");
                /* code */
            }
        }
    };
} // namespace hand_action_namespace

RCLCPP_COMPONENTS_REGISTER_NODE(hand_action_namespace::HandActionServer);