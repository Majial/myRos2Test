#include <iostream>
#include <rclcpp/rclcpp.hpp>

int main()
{
    std::cout<<"hello world"<<std::endl;
}